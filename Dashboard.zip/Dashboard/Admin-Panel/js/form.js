$(function() {
    $(".profileForm").on('submit', function(e){
        
        // USe validation of form 10 pts
        // use if 5 pts
        // use if-else 5 pts
        // use nested if else 5 pts
        //use getElementByTagName 2 pts used as jquery
        
        var pattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        var is_valid_email = pattern.test($("#email").val());
        
        if ($("#email").val() == "" || !is_valid_email) {
            e.preventDefault();
            if($("#email").next('.error').length == 0) {
                
                $("#email").after("<div class='error'>Please enter a valid email address</div>");    
            }
            
        } else {
            $("#email").next('.error').remove();
        }
        
        
        
        if ($("#fname").val() == "") {
            e.preventDefault();
            
            if($("#fname").next('.error').length == 0) {
                
                $("#fname").after("<div class='error'>Please enter your first name</div>");
            }
        } else {
            $("#fname").next('.error').remove();
        }
        
        
        
        
        if ($("#lname").val() == "") {
            e.preventDefault();
            
            if($("#lname").next('.error').length == 0) {
                
                $("#lname").after("<div class='error'>Please enter your last name</div>");
            }
        } else {
            $("#lname").next('.error').remove();
        }
        
        
        
        
        if ($("#address").val() == "") {
            e.preventDefault();
            
            if($("#address").next('.error').length == 0) {
                
                $("#address").after("<div class='error'>Please enter your address</div>");
            }
        } else {
            $("#address").next('.error').remove();
        }
        
        
        
        if ($("#city").val() == "") {
            e.preventDefault();
            
            if($("#city").next('.error').length == 0) {
                
                $("#city").after("<div class='error'>Please enter your city</div>");
            }
        } else {
            $("#city").next('.error').remove();
        }
        
        
        
        if ($("#country").val() == "") {
            e.preventDefault();
            
            if($("#country").next('.error').length == 0) {
                
                $("#country").after("<div class='error'>Please enter your country</div>");
            }
        } else {
            $("#country").next('.error').remove();
        }
        
        
        if ($("#country").val() != "" || $("#city").val() != "" || $("#address").val() != "" || $("#fname").val() != "" || $("#lname").val() != "" || $("#email").val() != "") {
            $('.card-body').find('.card-category').text($('#address').val()+', '+$('#city').val()+'/'+$('#country').val());
        
            $('.card-body').find('.card-title').text($('#fname').val()+' '+$('#lname').val());

            $('.card-body').find('.card-description').text($('#about').val());

            $('.card-body').find('.btn-round').text($('#email').val());
        }
        
        
        
        
        
    });
});