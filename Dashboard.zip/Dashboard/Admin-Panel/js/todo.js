$(function() {
    
    //USe for loop 10 pts
    // USe append() 2pts
    //USe jQuery Plugin 10 pts
    //Use array 2 pts
    //USe object with method 5 pts
    // use an object with array for a property value 5 pts 
    
    var tasks = ['first task', 'second task', 'third task', 'fourth task'];
    var time = ['10/08/2019 2:26PM', '27/09/2019 8:00AM', '13/10/2019 11:15PM', '07/11/2019 10:00AM'];
    var complete = ['fifth task'];
    var incomplete = ['sixth task'];
    var data;
    
    for (var i = 0; i < tasks.length; i++) {
        data = '<tr><td><div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" value="'+i+'"><span class="form-check-sign"> <span class="check"></span></span></label></div></td><td id="task'+i+'">'+ time[i]+ ' ' +tasks[i]+'</td><td class="td-actions text-right"><button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm" id="delete" data="'+i+'"><i class="material-icons">close</i></button></td></tr>';
        

        $('#tasks').find('tbody').append(data);
    }
    
    
    $('tbody').on('click', '.form-check input[type="checkbox"]', function(){
        var index = $(this).val();
        if ($(this).is(':checked')) {
            $("#task"+index).html('<strike>'+ time[index]+ ' ' +tasks[index]+'</strike>');
            
            complete.push(time[index] + ' ' +tasks[index]);
            
            tasks = jQuery.grep(tasks, function(value) {
              return value != tasks[index];
            });

            time = jQuery.grep(time, function(value) {
              return value != tasks[index];
            });
            
        } else {
            $("#task"+index).html(time[index]+ ' ' +tasks[index]);
            tasks.push(tasks[index]);
            time.push(time[index]);
        }
    });
    

    
    
    $('#datetimepicker4').datetimepicker();
    
    $('a.nav-link').on('click', function(){
        var href = $(this).attr('href');
        $('a.nav-link').removeClass('active');
        $('.tab-pane').hide();
        $(this).addClass('active');
        $(href).show();
        
        if (href === "#completed") {
            for (var j = 0; j < complete.length; j++) {
                data = '<tr><td><div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" disabled checked value="'+i+'"><span class="form-check-sign"> <span class="check"></span></span></label></div></td><td id="task'+j+'">'+ time[j]+ ' ' +complete[j]+'</td></tr>';


                $('#completed').find('tbody').append(data);
            }
        }
        
        if (href === "#incomplete") {
            
            for (var j = 0; j < incomplete.length; j++) {
                data = '<tr><td><div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" disabled value="'+i+'"><span class="form-check-sign"> <span class="check"></span></span></label></div></td><td id="task'+j+'">'+ time[j]+ ' ' +incomplete[j]+'</td></tr>';


                $('#incomplete').find('tbody').append(data);
            }
        }
    });
    
    $('tbody').on('click', '#delete', function(){
        $(this).parent().parent().remove();
    });
    
    $('.addTask').on('click', function(e){
        var task = $('#task').val();
        var date = $('#datetimepicker4').val();
        
        if (task == "" || date == "") {
            alert('Please enter the input fields');
            
        } else {
            tasks.push(task);
            time.push(date);
        }
        
        $('#tasks').find('tbody tr').remove();  
        
        for (var i = 0; i < tasks.length; i++) {
            data = '<tr><td><div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" value="'+i+'"><span class="form-check-sign"> <span class="check"></span></span></label></div></td><td id="task'+i+'">'+ time[i]+ ' ' +tasks[i]+'</td><td class="td-actions text-right"><button type="button" id="edit" data="'+i+'" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm"><i class="material-icons">edit</i></button><button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm" id="delete" data="'+i+'"><i class="material-icons">close</i></button></td></tr>';


            $('#tasks').find('tbody').append(data);
        }
    });
    
    

    
    
});