"use strict";

$(function() {
    
    //USe custom function 2pts
    
    //USe jQuery methods (10-15) 15 pts
    
    // Use global variable 5 pts
    // use localStorage
    //use jQuery UI 10pts
    //use JSON 15pts
    // Use "this" keyword 5 pts
    //USe event.stopPropagation() 10 pts
    
    var poll = [];
    
    
    $('.showPoll').append("<tr><td>"+poll+"</td></tr>");
    
    
    $.getJSON("../json/values.json", function(data) {
        $.each(data, function() {
            
            // Use "this" keyword 5 pts
            $.each(this, function(key, value) {
                
                // Use Local-Storage 5 pts
                
                
                localStorage.setItem('question', value.question);
                localStorage.setItem('option1', value.option1);
                localStorage.setItem('option2', value.option2);
                localStorage.setItem('option3', value.option3);               localStorage.setItem('option4', value.option4);
                localStorage.setItem('ans', value.ans);
                
                $('.card').find('.card-body.table-responsive').find('tbody').html(
                    '<tr><td>'+value.question+'</td></tr>'
                );

                
            });
        }); 
    });

    
    $()
    
    
    
    $('.sidebar-wrapper').css({
        "background-image" : "url('../img/sidebar-1.jpg')",
        "background-repeat" : "no-repeat",
        "background-position" : "center",
        "background-size" : "cover",
    });
    
    
    $('.fixed-plugin').on('click', function(e){
        
        //Use if-else 5 pts
        
        if ($('.fixed-plugin .dropdown').hasClass("show")) {
            $(".dropdown").removeClass("show");
            $(".dropdown-menu").removeClass("show");
            
        } else {
            $(".dropdown").addClass("show");
            $(".dropdown-menu").addClass("show");
        }
        
        
    });
    
    $('a.img-holder').on('click', function(e){
        e.stopPropagation();
        var _url = $(this).attr('data');
         $('.sidebar-wrapper').css({
            "background-image" : "url('../"+_url+"')",
            "background-repeat" : "no-repeat",
            "background-position" : "center",
            "background-size" : "cover",
        });
     });
    
    $('.badge-colors').find('span').on('click', function(e){
        e.stopPropagation();
        var clr = $(this).attr('data-color');
        if (clr === "rose") {
            clr = "#e91e63";
        } else if (clr === "azure") {
            clr = "#6ad0d0";
        } else if (clr === "danger") {
            clr = "red";
        }
        $('.sidebar li.active>a').css({'background-color':clr});
    });
    
    
    
    $('.badge-colors').find('span').on('click', function(){
        var clr = $(this).attr('data-color');
        if (clr === "rose") {
            clr = "#e91e63";
        } else if (clr === "azure") {
            clr = "#6ad0d0";
        } else if (clr === "danger") {
            clr = "red";
        }
        $('.sidebar li.active>a').css({'background-color':clr});
    });
    
    
    
    
    
    setInterval(typingEffect, 12000);
    typingEffect();
    
    var i,j;
    
    
    const $ques    = $("#ques"),
          $option1 = $("#option1"),
          $option2 = $("#option2");
    
    var inputs = ["#option3", "#option4", ".radio1", ".radio2", ".radio3", ".radio4"];
    
    for (i in inputs) {
        $(inputs[i]).hide();
    }
    
    $("form").submit(function(e){
        
        //Use NOT 5 pts, OR 5 pts  
        
        if ( !$ques.val() || !$option1.val() || !$option2.val() ) {
            e.preventDefault();
            
        } else {

            var index = jQuery.inArray( $ques.val(), poll );
                localStorage.setItem('question', $ques.val());
                localStorage.setItem('option1', value.option1);
                localStorage.setItem('option2', value.option2);
                localStorage.setItem('option3', value.option3);               localStorage.setItem('option4', value.option4);
                localStorage.setItem('ans', value.ans);
            
            $('.showPoll').append("<tr><td>"+localStorage.getItem('question')+"</td></tr>");
            
        }
        
    });
    

    

    
    $(".clear").on('click', function(){
        $ques.val("");
        $("input[type='text']").val("");
        for (i in inputs) {
            $(inputs[i]).hide();
        }
    });
    
    $(".uncheck").on('click', function(){
        $("input[name='options']").prop("checked", false);

    });

    $("input").on("keyup", function(){
        
        // USe $(this)
        const $this  = $(this);
        
        var hasValue = $this.val(),
            _option1 = $("#option1").val(),
            _option2 = $("#option2").val(),
            _option3 = $("#option3").val(),
            _option4 = $("#option4").val();

        
        if (hasValue) {
            $this.next().show();
            
        } else {
            $this.next().hide();
        }

        
        // Use AND 5 pts
        if (_option1 && _option2) {
            $("#option3").show();
            
        } else {
            $("#option3").hide();
            $(".radio3").hide();
        }
        
        if (_option1 && _option2 && _option3) {
            $("#option4").show();
            $(".radio3").show();
            
        } else {
            $("#option4").hide();
            $(".radio4").hide();
        }
        
        if (_option4 && $("#option3").is(":visible") && _option3) {
            $(".radio4").show();
        }
    });

});

// Use custom Function 2pts

function typingEffect() {
    var i = 0;
    var j = 0;
    var para = "";
    var txt = "Write your question here........";
    var speed = 180;
    addText();
    increment();
    function addText() {
        if (i < txt.length) {
            para += txt.charAt(i);
            $("#ques").attr("placeholder", para); 
            i++;
            setTimeout(addText, speed);
            
        }
    }
    
    function increment() {
        if (j != txt.length) {
            j++;
            setTimeout(increment, speed);
            
        } else {
            removeText();
        }
        
    }
    
    function removeText() {
        if (j <= txt.length && j >= 0) {
            txt = txt.substr(0, j);
            $("#ques").attr("placeholder", txt); 
            j--;
            setTimeout(removeText, speed);
        }
    }
}

$(document).on('click', '.navbar-toggler', function() {
    
    var $toggle = $(this);
    var mobile_menu_visible;
    
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        mobile_menu_visible = 1;
        
    } else {
        mobile_menu_visible = 0;
    }

  if (mobile_menu_visible == 1) {
    $('html').removeClass('nav-open');

    $('.close-layer').remove();
    setTimeout(function() {
      $toggle.removeClass('toggled');
    }, 400);

    mobile_menu_visible = 0;
  } else {
    setTimeout(function() {
      $toggle.addClass('toggled');
    }, 430);

    var $layer = $('<div class="close-layer"></div>');

    if ($('body').find('.main-panel').length != 0) {
      $layer.appendTo(".main-panel");

    } else if (($('body').hasClass('off-canvas-sidebar'))) {
      $layer.appendTo(".wrapper-full-page");
    }

    setTimeout(function() {
      $layer.addClass('visible');
    }, 100);

    $layer.click(function() {
      $('html').removeClass('nav-open');
      mobile_menu_visible = 0;

      $layer.removeClass('visible');

      setTimeout(function() {
        $layer.remove();
        $toggle.removeClass('toggled');

      }, 400);
    });

    $('html').addClass('nav-open');
    mobile_menu_visible = 1;

  }

});

